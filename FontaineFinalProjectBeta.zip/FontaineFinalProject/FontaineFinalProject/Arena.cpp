#include "stdafx.h"
#include "Arena.h"
//#include <iostream>
#include <ctime>
#include <iomanip>
#include <conio.h>
#include <stdlib.h>
#include "Bear.h"
#include "Wolf.h"
#include "Monster.h"
#include "Lion.h"
#include "Sprite.h"
#include <vector>
#include <fstream>
//#include <algorithm>

using namespace std; 

Arena::Arena(){}
//Arena::Arena(Sprite *pc){
//	NPC = NULL;
//	PC = pc;
//	Winner = NULL;
//	Loser = NULL;
//	bool looper = true;
//	char sel = 'x';
//	char cont = 'x';
//
//
//}
Arena::Arena(Sprite *pc, Sprite *npc)
{
	SAVEFILENAME = "arena_pc_saves.sav";
	NPC = NULL; 
	PC = pc; 
	Winner = NULL; 
	Loser = NULL; 
	bool looper = true; 
	char sel = 'x';
	char cont = 'x';
	loadNPCList(); 
	ArenaMenu(); 
}


Arena::~Arena()
{
}

void Arena::fight() {
	srand(time(NULL)); 
	bool looper = true;
	bool ran = false; 
	char select = 'x';
	fightDisplay();
	//select = _getch();
	while(looper){
		//system("cls"); 
		//fightDisplay(); 
		select =_getch();
		system("cls"); 
		//cout << select << endl;
		switch (select) {
		case 'a':
		case 'A':
			cout << "\n\n"; 
			NPC->ResolveAttack(PC->getName(), PC->Attack(NPC->getToHit()));
			PC->ResolveAttack(NPC->getName(), NPC->Attack(PC->getToHit()));
			if (NPC->getHitPoints() <= 0 || PC->getHitPoints() <= 0) {
				looper = false; 
			}
			break;
		case 'r':
		case 'R':looper = false; 
			ran = true; 
			break;
		}//switch
		fightDisplay(looper);
	}//while
	
	if (PC->getHitPoints() > 0 && NPC->getHitPoints() <= 0) {
		Winner = PC; 
		Loser = NPC; 
	}
	else if (NPC->getHitPoints() > 0 && PC->getHitPoints() <= 0) {
		Winner = NPC;
		Loser = PC; 
	}
	else {
		Winner = NULL; 
	}
	if (Winner != NULL) {
		string margin = "               ";
		system("cls");
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "The winner is " + Winner->getName() << "*" << endl;
		cout << margin + "*" << setw(48) << "The winner gets " + to_string(Loser->getCash()) << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		Winner->setCash(Winner->getCash() + Loser->getCash());
		cout << margin + "*" << setw(48) << "The winner's total cash is: " + to_string(Winner->getCash()) << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		Winner->addFightRecord(Loser); 
		
		cout << margin + "Press any key to continue... " << endl; 
		_getch(); 
		Winner->printFightRecord(); 
		cout << "Press Any Key To Continue...\n"; 
		_getch(); 

	}
	else if(ran) {
		string margin = "               ";
		system("cls");
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "The Coward "+PC->getName()<< "*" << endl;
		cout << margin + "*" << setw(48) << "ran from the vicious " + NPC->getName() << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << margin + "Press any key to continue... " << endl;
		cout << setfill(' ') << left;
		_getch();
	
	
	}
	else {
		string margin = "               ";
		system("cls");
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "Both combatants died, no winner." << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << margin + "Press any key to continue... " << endl;
		cout << setfill(' ') << left;
		_getch(); 
	}

}

void Arena::setNPC(Sprite *npc) {
	NPC = npc; 

}

void Arena::setPC(Sprite *pc) {
	PC = pc; 
}

Sprite* Arena::getNPC() {

	return NPC; 
}
Sprite* Arena::getPC() {

	return PC; 
}


//MonsterMenu() is depreciated use NPCMenu()
void Arena::MonsterMenu(bool &loop) {
	
	bool looper = true;
	char sel = 'x';
	char cont = 'x';
	string margin = "               ";

	while (looper) {
		system("cls");
		cout << endl << endl << endl << endl; 
		cout << margin << setw(50) << setfill('*') << "" << endl; 
		cout << setfill(' ') << left; 
		cout << margin + "*" << setw(48) <<"    What you would like to fight:" << "*" << endl;
		cout << margin + "*" << setw(48) <<"    (B)ear" << "*" <<endl;
		cout << margin + "*" << setw(48) <<"    (L)ion" << "*" <<endl;
		cout << margin + "*" << setw(48) <<"    (W)olf" << "*" <<endl;
		cout << margin + "*" << setw(48) <<""<<"*"<< endl;
		cout << margin + "*" << setw(48) <<"    (Q)uit" << "*" << endl;
		//cout << "(Q)uit" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ');
		cout << margin +"Select(B, L, W, or Q): " << endl;
		sel = _getch();
		cout << sel << endl; 
		switch (sel) {
		case 'B':
		case 'b': NPC = new Bear();
			system("cls");
			looper = false; 
			break;
		case 'L':
		case 'l': NPC = new Lion();
			system("cls");
			looper = false;
			break;
		case 'W':
		case 'w': NPC = new Wolf();
			system("cls");
			looper = false;
			break;
		case 'q':
		case 'Q': loop = false;
			looper = false;
			continue;
		default: system("cls");
			continue;
		}

	}


}

void Arena::fightDisplay() {
	string margin = "       ";
	string smallmargin = "    ";
	system("cls"); 
	cout << endl << endl << endl << endl; 
	cout << margin << setw(50) << setfill('*') << ""<< endl; 
	cout << setfill(' ') << left; 
	cout << margin + "*" << setw(48) <<"" << "*" << endl;
	cout << margin + "*" << setw(48) <<"" << "*" << endl;
	cout << margin + "*" << setw(48) << smallmargin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
	cout << margin + "*" << setw(48) << "" <<"*" << endl;
	cout << margin + "*" << setw(48) << smallmargin + NPC->getName() + "'s Hitpoints: " + NPC->hitPointsToString() + "/" + NPC->MAXHITPOINTSToString() << "*" <<endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << "" <<"*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin << setfill('*') << setw(50) <<""<< endl;
	cout << margin + "(A)ttack or (R)un? ";
}
void Arena::fightDisplay(bool test) {
	string margin = "       ";
	string smallmargin = "    ";
	//system("cls");
	cout << endl << endl;
	cout << margin << setw(50) << setfill('*') << "" << endl;
	cout << setfill(' ') << left;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << smallmargin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << smallmargin + NPC->getName() + "'s Hitpoints: " + NPC->hitPointsToString() + "/" + NPC->MAXHITPOINTSToString() << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin << setfill('*') << setw(50) << "" << endl;
	cout << margin + "(A)ttack or (R)un? ";
}



void Arena::ArenaMenu() {
	char selection = 'x';
	bool loop = true; 
	bool alive = true;
	string margin = "               ";
	while (loop) {
		if (PC->isAlive()) {
			
			system("cls");
			cout << endl << endl << endl << endl;
			cout << margin << setw(50) << setfill('*') << "" << endl;
			cout << setfill(' ') << left;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "     (F)ight" << "*" << endl;
			cout << margin + "*" << setw(48) << "     (H)ealers Hut" << "*" << endl;
			cout << margin + "*" << setw(48) << "     (S)tore" << "*" << endl;
			cout << margin + "*" << setw(48) << "     (C)haracter Sheet" << "*" << endl;
			cout << margin + "*" << setw(48) << "     sa(V)e Character" << "*" << endl;
			cout << margin + "*" << setw(48) << "     (Q)uit" << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin << setw(50) << setfill('*') << "" << endl;
			cout << setfill(' ') << left;
			cout << margin + "Make Selection: " << endl;
			selection = _getch();

			switch (selection) {
				// case t for Testing new arean features
/*			case 't':
			case 'T':system("cls");
				SaveCharacterMenu();
				break;*/ 
			case 'h':
			case 'H':
				HealersHutMenu();
				break;
			case 's':
			case 'S':
				StoreMenu(); 
				break;
			case 'c':
			case 'C':PC->printSheet(); 
				cout << "\nPress Any Key To Continue...\n"; 
				_getch(); 
				break; 
			case 'Q':
			case 'q': {
				loop = false;
				bool validchoice = false;
				char choice = 'x';
				if (PC->isAlive()) {
					while (!validchoice) {
						cout << "\n          Save Character? (Y\N)";
						choice = _getch();
						if (toupper(choice) == 'Y' || toupper(choice) == 'N')
							validchoice = true;
						else
							cout << "\n          Save Character? (Y/N)";
					}// end while !validchoice
					if (toupper(choice) == 'Y')
						std::system("cls");
						SaveCharacterMenu();
					continue;
					break;
				}//end if Alive
			}//end case
			case 'v':
			case 'V':
				system("cls");
				//PC->saveSprite(); 
				SaveCharacterMenu();
				break; 
			case 'f':
			case 'F':
				system("cls"); 
				NPCMenu();
				cout << "Press any key to continue...\n"; 
				_getch();
				system("cls");
				break;
			default:
				system("cls");
				continue;
			}
		}
		else {
			cout << endl << endl << endl << endl;
			cout << margin << setw(50) << setfill('*') << "" << endl;
			cout << setfill(' ') << left;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "     " + PC->getName() + " has died" << "*" << endl;
			cout << margin + "*" << setw(48) << "     Ending Gold is " + to_string(PC->getCash()) << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin + "*" << setw(48) << "" << "*" << endl;
			cout << margin << setw(50) << setfill('*') << "" << endl;
			cout << setfill(' ') << left;
			//cout << margin + "Press any key to continue..." << endl; 
			//_getch(); 
			
			PC->printFightRecord(); 
			cout << margin + "Press any key to continue..." << endl;
			_getch(); 

			loop = false; 
		}

		system("cls"); 
	}





}
void Arena::HealersHutMenu() {
	string margin = "               ";
	bool looper = true;
	char select = 'x'; 
	while (looper) {
		system("cls");

		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName()  + " : " + to_string(PC->getCash())+" GP" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(H)eal 100 HP (100 GP)" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(Q)uit" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;

		select = _getch();
		switch (select) {
		case 'h': 
		case 'H':
			if (PC->getCash() >= 100) {
				if ((PC->getMAXHITPOINTS() - PC->getHitPoints()) > 100) {
					PC->setCash(PC->getCash() - 100); 
					PC->setHitPoints(PC->getHitPoints() + 100); 
				}
				else {
					PC->setCash(PC->getCash() - 100);
					PC->setHitPoints(PC->getMAXHITPOINTS()); 
				}
			}
			else {
				cout << margin + "You have insufficent funds to Heal." << endl; 
				cout << margin + "Press any key to continue..."; 
				_getch(); 

			}
			break; 
		case 'Q':
		case 'q': looper = false; 
			continue;
			break; 
		default:
			system("cls");
			continue; 

		}//switch



	}//end while





}
void Arena::StoreMenu() {
	string margin = "               ";
	bool looper = true;
	char select = 'x';
	

	while (looper) {
		system("cls");
		string smallmargin = "    ";
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << smallmargin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
		cout << margin + "*" << setw(48) << smallmargin + PC->getName() + " : " + to_string(PC->getCash()) + " GP" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << smallmargin + "(A)rmor Store" << "*" << endl;
		cout << margin + "*" << setw(48) << smallmargin + "(W)eapon Store" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << smallmargin + "(Q)uit" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
	

	select = _getch();

	switch (select) {
	case 'A':
	case 'a':
		ArmorMenu();
		break;
	case 'w':
	case 'W':
		WeaponMenu();
		break;
	case 'q':
	case 'Q':
		looper = false; 
		break;
	default:
		continue; 
		break; 

		}//switch

	}//while


}

void Arena::ArmorMenu(){
	string margin = "               ";
	bool looper = true;
	char select = 'x';
	
	while (looper) {
		system("cls");
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName() + " : " + to_string(PC->getCash()) + " GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(L)eather Armor 200 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(C)hainmail     400 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(S)cale Mail    800 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(H)alf-Plate   1600 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(F)ull Plate   3600 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(Q)uit" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;

		select = _getch(); 

		switch (select) {
		case 'l':
		case 'L': if (PC->getCash() >= 200) {
			int newArmor = 100;
			string newArmorName = "Leather";
			int currentArmor = PC->getArmor();
			int armorDiff = newArmor - currentArmor;
			PC->setCash(PC->getCash() - 200);
			PC->setArmor(newArmor, newArmorName);
			PC->setMAXHITPOINTS();
			PC->setHitPoints(PC->getHitPoints() + armorDiff);

		}
				  else {
					  cout << "Insufficent Gold" << endl; 
					  cout << "Press any key to continue..."; 
					  _getch(); 

				  }

				  break;
		case 'C':
		case 'c':if (PC->getCash() >= 400) {
			int newArmor = 200;
			string newArmorName = "Chainmail"; 
			int currentArmor = PC->getArmor();
			int armorDiff = newArmor - currentArmor;
			PC->setCash(PC->getCash() - 400);
			PC->setArmor(newArmor, newArmorName);
			PC->setMAXHITPOINTS();
			PC->setHitPoints(PC->getHitPoints() + armorDiff);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
				 break;
		case 'S':
		case 's':if (PC->getCash() >= 800) {
			int newArmor = 300;
			string newArmorName = "Scale Mail";
			int currentArmor = PC->getArmor();
			int armorDiff = newArmor - currentArmor;
			PC->setCash(PC->getCash() - 800);
			PC->setArmor(newArmor, newArmorName);
			PC->setMAXHITPOINTS();
			PC->setHitPoints(PC->getHitPoints() + armorDiff);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
				 break;
		case 'h':
		case 'H':if (PC->getCash() >= 1600) {
			int newArmor = 400;
			string newArmorName = "Half-Plate";
			int currentArmor = PC->getArmor();
			int armorDiff = newArmor - currentArmor;
			PC->setCash(PC->getCash() - 1600);
			PC->setArmor(newArmor, newArmorName);
			PC->setMAXHITPOINTS();
			PC->setHitPoints(PC->getHitPoints() + armorDiff);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
				 break;
		case 'F':
		case 'f':if (PC->getCash() >= 3200) {
			int newArmor = 500;
			string newArmorName = "Full-Plate";
			int currentArmor = PC->getArmor();
			int armorDiff = newArmor - currentArmor;
			PC->setCash(PC->getCash() - 3200);
			PC->setArmor(newArmor, newArmorName);
			PC->setMAXHITPOINTS();
			PC->setHitPoints(PC->getHitPoints() + armorDiff);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
				 break;
		case 'q':
		case 'Q':looper = false;
			continue;
			break;
		default:
			system("cls");
			continue;
			break;
		}//switch


	}//while loop




}
void Arena::WeaponMenu() {
	string margin = "               ";
	bool looper = true;
	char select = 'x';
	int cost = 0;

	while (looper) {
		system("cls");
		cout << endl << endl << endl << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;
		cout << margin + "*" << setw(48) << "" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName() + "'s Hitpoints: " + PC->hitPointsToString() + "/" + PC->MAXHITPOINTSToString() << "*" << endl;
		cout << margin + "*" << setw(48) << margin + PC->getName() + " : " + to_string(PC->getCash()) + " GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(D)agger       200 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(S)hort Sword  400 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(A)x           800 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(L)ong Sword  1600 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(G)reat Sword 3200 GP" << "*" << endl;
		cout << margin + "*" << setw(48) << margin + "(Q)uit" << "*" << endl;
		cout << margin << setw(50) << setfill('*') << "" << endl;
		cout << setfill(' ') << left;

		select = _getch();
		switch (select) {
		case 'd':
		case 'D':if (PC->getCash() >= 200) {
			int newWeapon = 2;
			PC->setCash(PC->getCash() - 200);
			PC->setWeapon(newWeapon);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
			break; 
		case 's':
		case 'S':cost = 400;
			if (PC->getCash() >= cost) {
			int newWeapon = 3;
			PC->setCash(PC->getCash() - cost);
			PC->setWeapon(newWeapon);

		}
				 else {
					 cout << "Insufficent Gold" << endl;
					 cout << "Press any key to continue...";
					 _getch();

				 }
			break; 
		case 'a':
		case 'A': cost = 800;
			if (PC->getCash() >= cost) {
				int newWeapon = 4;
				PC->setCash(PC->getCash() - cost);
				PC->setWeapon(newWeapon);

			}
			else {
				cout << "Insufficent Gold" << endl;
				cout << "Press any key to continue...";
				_getch();

			}
			break;
		case 'l':
		case 'L':cost = 1600;
			if (PC->getCash() >= cost) {
				int newWeapon = 5;
				PC->setCash(PC->getCash() - cost);
				PC->setWeapon(newWeapon);

			}
			else {
				cout << "Insufficent Gold" << endl;
				cout << "Press any key to continue...";
				_getch();

			}
			break; 
		case 'g':
		case 'G':cost = 3200;
			if (PC->getCash() >= cost) {
				int newWeapon = 6;
				PC->setCash(PC->getCash() - cost);
				PC->setWeapon(newWeapon);

			}
			else {
				cout << "Insufficent Gold" << endl;
				cout << "Press any key to continue...";
				_getch();

			}
			break;
		case 'q':
		case 'Q':
			system("cls");
			looper = false; 
			break; 






		}//switch

	}//while

}//WeaponMenu
void Arena::loadNPCList() {
	string filename = "NPCList.sav"; 
	string name;
	string wname; 
	string aname; 
	int b;
	int q;
	int i;
	int s;
	int arm;
	int wep;
	int HP;
	int tH;
	int csh;
	int attk;
	Monster *monster;
	ifstream npcfile; 
	npcfile.open(filename);
	if (npcfile.is_open()) {
		if (npcfile.good()) {
			getline(npcfile, name);
			getline(npcfile, name);
			getline(npcfile, name);
			getline(npcfile, name);
			while (npcfile.good())
			{
				try {
					getline(npcfile, name);
					npcfile >> b >> q >> s >> i >> wep >> arm >> csh;
					npcfile.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					getline(npcfile, wname); 
					getline(npcfile, aname);
					monster = new Monster(name, b, i,q,s,wep,arm,csh, wname, aname);
					NPCList.push_back(*monster);
				}
				catch (exception ex) {
					cout << "NPCS FAILED TO LOAD FROM FILE" << endl;
					cout << "Press Any Key To Continue..." << endl;
					_getch();
				}
			}//while

		}//if
		else {
			cout << "NPC File Not Found!!!!" << endl;
			cout << "Press Any Key To Continue..." << endl;
			_getch();

		}//else

	}// if

	npcfile.close(); 
}

vector<Monster> Arena::getNPCList(){
	return NPCList; 
}
void Arena::printNPCList() {
	int sel=0; 
	bool valid = false; 
	string margin = "              ";
	if (NPCList.size() <= 0) {
		cout << "No Saved Characters..." << endl;
		cout << "Press Any Key To Continue..." << endl;
		_getch();
	}
	else {
		cout << margin << "Save #" << margin << setw(20) << "Monster Name" << endl;
		cout << margin << "======" << margin << setw(20) << setfill('=')<<"" << setfill(' ')<<endl;
		for (int i = 0; i < NPCList.size(); i++) {
			cout << margin << setw(4) << to_string(i + 1) << margin<< setw(20) << NPCList[i].getName() << endl;
		}

	}
	//cout << "Please enter Selection to see Character Sheet and press <enter>... 0 to quit"; 
	//while (!valid) {
	//	//cout << " in while \n";
	//	if (cin >> sel) {
	//		//cout << " in if\n";
	//		if (sel == 0)
	//		{
	//			cout << "in 2nd if\n"; 
	//			valid = true; 
	//		}//if
	//		else if ((sel - 1) <= NPCList.size()) {
	//			//cout << " in else if. Sel =\n" + to_string(sel); 
	//			NPCList[sel-1].printSheet();
	//			valid = true; 
	//		}//else if
	//		else {
	//			//cout << " in else. Sel = \n" + to_string(sel);
	//			cin.clear();
	//			cin.ignore();
	//		}//else
	//	}//if
	//	cin.clear();
	//	cin.ignore();
	//}//while
	////cout << "Press Any Key To Continue" << endl;  

}

void Arena::NPCMenu() {
	int sel; 
	bool valid = false; 
	bool looper = true; 
	bool alive = true; 
	char selecter = 'x'; 
	while (looper) {
		if (PC->isAlive()) {
			valid = false;
			system("cls");
			//printNPCList();
			//cout << "          Please enter Selection press <enter>... 0 to quit:  ";
			while (!valid) {
				printNPCList(); 
				cout << "\n          Please enter Selection press <enter>... 0 to quit:  ";
				//cout << "loop 1\n" << NPCList.size() << endl; 
				if (std::cin >> sel) {
					//cout << sel << endl; 
					if (sel == 0)
					{
						valid = true;
						looper = false;
					}//if sel == 0
					else if (sel <= NPCList.size()) {
						NPCList[sel - 1].printSheet();
						cout << "          Do you want to fight " + NPCList[sel - 1].getName() + "? (y/n)\n";
						
						bool looper2 = true;
						while (looper2) {
							//cout << "loop 2\n";
							selecter = _getch();
							switch (selecter) {
							case 'y':
							case 'Y': {
								NPC = new Monster(NPCList[sel - 1].getName(), NPCList[sel - 1].getBody(), NPCList[sel - 1].getIntelligence(), NPCList[sel - 1].getQuickness(), NPCList[sel - 1].getStrength(), NPCList[sel - 1].getWeapon(), NPCList[sel - 1].getArmor(), NPCList[sel - 1].getCash(), NPCList[sel - 1].getWeaponName(), NPCList[sel - 1].getArmorName());
								fight();
								delete NPC;
								if (PC->getHitPoints() <= 0) {
									alive = false;
								}//if
								looper2 = false;
								break;
							}//case
							case 'n':
							case 'N':looper2 = false;
								break;
							default:
								break;
							}//switch
						}//while
						valid = true;
					}//else if
					else {
						system("cls"); 
						cout << "Please Enter a valid selection: \n";
						//std::cin.clear();
						//std::cin.ignore();
					}//else
				}//if
				std::cin.clear();
				std::cin.ignore();
				std::system("cls");
			}//while valid
		}//if
		else {
			looper = false; 
		}//else


	}//while



}
vector<Sprite> Arena::getSaveCharacterList() {
	vector<Sprite> spriteList;
	string name;
	int b;
	int q;
	int i;
	int s;
	int arm;
	int wep;
	int HP;
	int csh;
	//int attk;
	Sprite *Character;
	string validate = "//Arena Copyright 2018 Mike Fontaine";
	bool isgood = false; 
	ifstream savefile;
	savefile.open(SAVEFILENAME);
	if (savefile.is_open()) {
		getline(savefile, name);
		if (name == validate) {
			getline(savefile, name);
			while (savefile.good())
			{
				try {
					getline(savefile, name);

					isgood = true;
					savefile >> b >> q >> s >> i >> arm >> wep >> csh >> HP;
					savefile.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					Character = new Sprite(name, b, i, q, s, csh, arm, wep, HP);
					spriteList.push_back(*Character);

				}
				catch (exception ex) {
					cout << "FAILED TO LOAD FROM FILE" << endl;
					cout << "Press Any Key To Continue..." << endl;
					_getch();
				}
			}
		}//while

	}
	if(!isgood) {
		cout << "File Not Found!!!!" << endl;
		cout << "Press Any Key To Continue..." << endl;
		_getch();

	}

	savefile.close();
	return spriteList;

}// end getSavedCharacterList; 
void Arena::printSaveCharacterList() {
	string margin = "              ";
	vector<Sprite> list = getSaveCharacterList();
	if (list.size() <= 0) {
		cout << "\n\nNo Saved Characters..." << endl;
		cout << "Press Any Key To Continue..." << endl;
		_getch();
	}
	else {
		cout << "\n\n";
		cout << margin << "Save #" << margin << "Character Name" << endl;
		cout << margin << "======" << margin << "==============" << endl;
		for (int i = 0; i < list.size(); i++) {
			cout << margin << setw(4) << to_string(i + 1) << margin << list[i].getName() << endl;
		}
		cout << "\n\n";
	}
	//cout << margin + "Press Any Key To Continue..." << endl;
}
void Arena::SaveCharacterMenu() {
	string validate = "//Arena Copyright 2018 Mike Fontaine";
	bool isgood = false;
	bool looper = true; 
	int choice; 
	string margin = "              ";
	while (looper) {
		system("cls");
		printSaveCharacterList();
		vector<Sprite> savList = getSaveCharacterList(); 
		if (savList.size() > 0) {
			cout << margin + "Enter Number of Slot to save in, 0 to exit, and press <<ENTER>>..." << endl;
			if (cin >> choice) {
				if (choice == 0) {
					//cout << "in if\n";
					looper = false;
				}//end if
				else if (choice <= savList.size()) {
					//cout << "in else if\n" + to_string(savList.size()) << endl;
				//	_getch(); 

					bool goodChoice = false;
					char printChoice = 'x'; 
					while (!goodChoice) {
						system("cls");
						savList[choice - 1].printSheet(); 
						cout << "\n          Replace this save?(Y/N)"; 
						printChoice = _getch();
						if (toupper(printChoice) == 'Y' || toupper(printChoice) == 'N')
							goodChoice = true; 
					}
					if (toupper(printChoice) == 'Y') {


						looper = false;
						ofstream sfile;
						sfile.open(SAVEFILENAME);
						savList.erase(savList.begin() + (choice - 1));
						savList.push_back(*PC);
						sfile << validate + "\n";
						for (int i = 0; i < savList.size(); i++) {
							//cout << "in for\n";
							sfile << "\n" + savList[i].toString();
						}//for
						sfile.close();
						cout << "Character Saved...\n Press Any Key To Continue...\n";
						_getch();
					}// end if print choice = y
				}//elseif
				else {
					system("cls");
					cout << "Please enter a valid choice... \n";
				}//else
			}//if
		}
		else {
			cout << "Saved character to slot 1" << endl; 
			ofstream sfile; 
			sfile.open(SAVEFILENAME); 
			sfile << "\n" + PC->toString();
			cout << "Press any key to continue...\n"; 
			_getch();
			looper = false; 
		}
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
	}//while


}