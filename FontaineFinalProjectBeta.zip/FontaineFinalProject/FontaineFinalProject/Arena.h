#pragma once
#include "stdafx.h"
#include "Sprite.h"
#include "Monster.h"
#include <vector>

class Arena
{
private:
	Sprite *PC; 
	Sprite *NPC; 
	Sprite *Winner;
	Sprite *Loser; 
	vector<Monster> NPCList; 
	string SAVEFILENAME;


public:
	Arena(); 
	Arena(Sprite *pc, Sprite *npc);
	//Arena(Sprite *pc); 
	~Arena();
	Sprite* getPC(); 
	Sprite* getNPC();
	void MonsterMenu(bool &loop); 
	void setPC(Sprite *player);
	void setNPC(Sprite *enemey); 
	void fight();
	void fightDisplay(); 
	void ArenaMenu(); 
	void HealersHutMenu();
	void StoreMenu(); 
	void ArmorMenu(); 
	void WeaponMenu(); 
	vector<Monster> getNPCList();
	void loadNPCList(); 
	void printNPCList(); 
	void NPCMenu(); 
	void fightDisplay(bool test); 
	vector<Sprite> getSaveCharacterList();
	void printSaveCharacterList();
	void SaveCharacterMenu();

};

