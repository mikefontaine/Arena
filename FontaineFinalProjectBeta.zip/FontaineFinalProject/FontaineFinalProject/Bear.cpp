#include "stdafx.h"
#include "Sprite.h"
#include "Monster.h"
#include "Bear.h"



Bear::Bear()
{
	setName("Bear");
	setStrength(30); 
	setIntelligence(5); 
	setQuickness(5); 
	setBody(40);
	setWeapon(3);
	setArmor(50);
	setCash(500);
	setMAXHITPOINTS();
	setHitPoints(getMAXHITPOINTS());
	setToHit();
	setAttack();
}


Bear::~Bear()
{
}
