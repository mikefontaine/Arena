#pragma once
#include "Monster.h"
class Bear :
	public Monster
{
public:
	Bear();
	~Bear();
};

