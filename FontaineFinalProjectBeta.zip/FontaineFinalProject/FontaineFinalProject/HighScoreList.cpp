#include "stdafx.h"
#include "HighScoreList.h"


HighScoreList::HighScoreList()
{
}


HighScoreList::~HighScoreList()
{
}
