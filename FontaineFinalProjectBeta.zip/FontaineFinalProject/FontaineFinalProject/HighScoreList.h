#pragma once
class HighScoreList
{
public:
	HighScoreList();
	~HighScoreList();
};

