#include "stdafx.h"
#include "Sprite.h"
#include "Monster.h"

#include "Lion.h"



Lion::Lion()
{
	setName("Lion");
	setStrength(20);
	setIntelligence(10);
	setQuickness(30);
	setBody(20);
	setWeapon(2);
	setArmor(10);
	setCash(300);
	setMAXHITPOINTS();
	setHitPoints(getMAXHITPOINTS());
	setToHit();
	setAttack();
}


Lion::~Lion()
{
}
