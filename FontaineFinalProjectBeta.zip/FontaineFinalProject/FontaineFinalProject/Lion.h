#pragma once
#include "Sprite.h"
#include "Monster.h"


class Lion :
	public Monster
{
public:
	Lion();
	~Lion();
};

