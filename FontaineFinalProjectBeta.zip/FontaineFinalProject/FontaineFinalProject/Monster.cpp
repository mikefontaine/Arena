#include "stdafx.h"
#include "Sprite.h"
#include "Monster.h"
#include <string>

using namespace std;




Monster::Monster():Sprite()
{

}

Monster::Monster(string na, int bd, int intel, int qk, int str, int gold):Sprite(na, bd, intel, qk, str) {
	setCash(gold); 
}

Monster::Monster(string na, int bd, int intel, int qk, int str, int weap, int arm, int gold, string weap_name, string arm_name) {
	setName(na);
	setBody(bd); 
	setIntelligence(intel); 
	setStrength(str); 
	setQuickness(qk);
	setCash(gold); 
	setWeapon(weap, weap_name);
	setArmor(arm, arm_name);
	setMAXHITPOINTS();
	setHitPoints(getMAXHITPOINTS());
	setToHit();
	setAttack();

}


Monster::~Monster()
{
}
