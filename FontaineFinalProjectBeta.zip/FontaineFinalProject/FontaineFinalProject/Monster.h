#pragma once
#include "Sprite.h"
class Monster :
	public Sprite
{
public:
	Monster(string na, int bd, int intel, int qk, int str, int gold);
	Monster(string na, int bd, int intel, int qk, int str, int weap, int arm, int gold, string weap_name, string arm_name); 
	Monster(); 
	~Monster();
};

