#include "stdafx.h"
#include "Sprite.h"
#include <iomanip>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <vector>



Sprite::Sprite()
{
	name = ""; 
	armor = 1;
	attack = 0;
	weapon = 1; 
	body = 0; 
	intelligence = 0; 
	quickness = 0; 
	strength = 0; 
	cash = 0;
	hitPoints = 0; 
	toHit = 0; 

}
Sprite::Sprite(string na, int bd, int intel, int qk, int str)
{
	name = na; 
	body = bd; 
	intelligence = intel; 
	strength = str; 
	quickness = qk; 
	cash = 0; 
	setWeapon(1);
	setArmor(0, "Tattered Rags");
	setMAXHITPOINTS();
	setHitPoints(MAXHITPOINTS);
	setToHit();
	setAttack(); 

}

Sprite::Sprite(string na, int bd, int intel, int qk, int str, int gld, int arm, int weap, int hp)
{
	name = na;
	body = bd;
	intelligence = intel;
	strength = str;
	quickness = qk;
	cash = gld;
	setWeapon(weap);
	setArmor(arm);
	setMAXHITPOINTS();
	setHitPoints(hp);
	setToHit();
	setAttack();

}


Sprite::~Sprite()
{
}
bool Sprite::isAlive() {
	if (hitPoints > 0)
		return true;
	else
		return false; 
}
void Sprite::setName(string n) {
	name = n; 
}
string Sprite::getName() {
	return name.substr(0,18); 
}

void Sprite::setArmor(int a) {
	armor = a; 
	setMAXHITPOINTS();
	switch(a) {
	case 0: armorName = "Skin";
		break; 
	case 1: 
		armorName = "Leather Armor";
		break; 
	case 2: 
		armorName = "Chainmail"; 
		break; 
	case 3:
		armorName = "Scale Male"; 
		break; 
	case 4:
		armorName = "Half Plate";
		break;
	case 5:
		armorName = "Full Plate"; 
		break; 
	}
}
void Sprite::setArmor(int a, string n) {
	armor = a;
	setMAXHITPOINTS();
	armorName = n;
}




int Sprite::getArmor() {
	return armor; 

}

int Sprite::getAttack(){
	return attack; 
}
void Sprite::setAttack() {
	attack = strength + weapon;
}

int Sprite::getWeapon(){
	return weapon;
}
void Sprite::setWeapon(int w){
	weapon = w;
	switch (w) {
	case 1:
		weaponName = "Fists";
		break;
	case 2:
		weaponName = "Dagger";
		break;
	case 3:
		weaponName = "Short Sword";
		break;
	case 4:
		weaponName = "Ax";
		break;
	case 5:
		weaponName = "Long Sword";
		break;
	case 6:
		weaponName = "Great Sword";
		break;
	}
}
void Sprite::setWeapon(int w, string n) {
	weapon = w; 
	weaponName = n; 
}

int Sprite::getBody(){
	return body; 

}
void Sprite::setBody(int b){
	body = b; 
}

void Sprite::setQuickness(int q){
	quickness = q; 
}
int Sprite::getQuickness(){
	return quickness; 

}

void Sprite::setIntelligence(int i){
	intelligence = i; 
}
int Sprite::getIntelligence(){
	return intelligence; 
}

int Sprite::getCash(){
	return cash; 
}
void Sprite::setCash(int c){
	cash = c; 
}



int Sprite::getHitPoints(){
	return hitPoints; 
}
void Sprite::setHitPoints(int hp){
	hitPoints = hp;
}

int Sprite::getToHit(){
	return toHit; 
}
void Sprite::setToHit(){
	toHit = quickness + armor;
}

int Sprite::getStrength(){
	return strength; 
}
void Sprite::setStrength(int s){
	strength = s; 
}
string Sprite::toString() {

	return  name + "\n" + to_string(body) + " " + to_string(quickness) + " " + to_string(strength) + " " + to_string(intelligence) + " " + to_string(armor) + " " + to_string(weapon) + " " + to_string(cash) + " " + to_string(hitPoints);


}
void Sprite::printSheet() {

	string margin = "               ";
	system("cls");
	cout << endl << endl << endl << endl;
	cout << margin << setw(50) << setfill('*') << "" << endl;
	cout << setfill(' ') << left;
	cout << margin + "*" << setw(20) << "     Name: " << setw(28) << getName() << "*" << endl;
	cout << margin + "*" << setw(20) << "     Body: " << setw(28) << to_string(getBody()) << "*" << endl;
	cout << margin + "*" << setw(20) << "     Quickness: " << setw(28) << to_string(getQuickness()) << "*" << endl;
	cout << margin + "*" << setw(20) << "     Strength: " << setw(28) << to_string(getStrength()) << "*" << endl;
	cout << margin + "*" << setw(20) << "     Intelligence: " << setw(28) << to_string(getIntelligence()) << "*" << endl;
	cout << margin + "*" << setw(20) << "     Hit Points: " << setw(28) << to_string(getHitPoints())+"//"+ to_string(getMAXHITPOINTS())<< "*" << endl;
	cout << margin + "*" << setw(20) << "     Armor: " << setw(28) << armorName << "*" << endl;
	cout << margin + "*" << setw(20) << "     Weapon: " << setw(28) << weaponName << "*" << endl;
	cout << margin + "*" << setw(48) << "" << "*" << endl;
	cout << margin << setw(50) << setfill('*') << "" << endl;
	cout << setfill(' '); 
	//cout << "Press any key to continue...";
	//_getch(); 









}
void Sprite::setMAXHITPOINTS() {

	MAXHITPOINTS = (body * 10) + armor;
	//setHitPoints(MAXHITPOINTS);
}
int Sprite::getMAXHITPOINTS() {
	return MAXHITPOINTS;
}
string Sprite::hitPointsToString() {

	return to_string(hitPoints); 


}
string Sprite::MAXHITPOINTSToString() {
	return to_string(MAXHITPOINTS); 
}

int Sprite::Attack(int targetNo) {
	int target = targetNo;
	//srand((int)time(0));
	int roll = rand() % 100 + getAttack(); 
	int damage = 0; 
	//cout << name + " rolled " + to_string(roll) + " against " + to_string(target) << endl; 
	if (roll > target) {
		damage = rand() % 10 * getWeapon();
		
	}
	return damage; 
}
void Sprite::ResolveAttack(string attacker, int damage) {
	//srand((int)time(0));
	string margin = "               ";
	if (damage <= 0) {
		cout << margin + attacker + " missed" << endl;
	}
	else {
		hitPoints = hitPoints - damage; 
		cout << margin + attacker + " hit for " + to_string(damage) << endl; 
	}

}
void Sprite::saveSprite() {
	// depreciated
	ofstream saveFile;

	saveFile.open("save1.sav");
	saveFile << name << "\n" << body << " " << quickness << " " << strength << " " << intelligence << " " << armor << " " << weapon << " " << cash << " " << hitPoints << endl;
	saveFile.close();
	cout << "Your Character has been saved...\n Press any key to continue ... " << endl;
	_getch();

}
void Sprite::saveSprite(int pos) {
	ofstream saveFile;
	//depreciated

	saveFile.open("save1.sav");
	saveFile << name << "\n" << body << " " << quickness << " " << strength << " " << intelligence << " " << armor << " " << weapon << " " << cash << " " << hitPoints << endl;
	saveFile.close();
	cout << "Your Character has been saved...\n Press any key to continue ... " << endl;
	_getch();

}

void Sprite::loadSpriteFromFile(string file) {
	//depreciated
	string cname;
	string tmp; 

	ifstream saveFile;
	saveFile.open(file);
	if (saveFile.is_open()) {
		//while (!saveFile.eof()) {
			//cout << " Testing... \n";
			getline(saveFile, name);
			//cout << cname << "Testing 2... \n";
			//getline(saveFile, tmp); 
			//cout << tmp << "Testing 3... \n"; 
			

			//cout << "\nTest 4"; 
			saveFile >> body >> quickness >> strength >> intelligence >> armor >> weapon >> cash >> attack >> hitPoints >> toHit;
			saveFile.close();
			setMAXHITPOINTS();
			setHitPoints(MAXHITPOINTS);
			setToHit();
			setAttack();
			setWeapon(weapon);
			setArmor(armor);

		//}//while loop 
	}//if 
	else {
		system("cls"); 
		cout << "ERROR: NO FILE!!!\n";

	}
	//cout << "\nTest 5"; 
}

void Sprite::addFightRecord(Sprite *NPC) {


	FightRecord fight = FightRecord(NPC->getName(),NPC->getCash());

	if (recordFights.size() == 0) {
		recordFights.push_back(fight);
	}
	else {
		bool dupe = false; 
		for (int i = 0; i < recordFights.size(); i++) {
			if (recordFights[i].name == fight.name) {
				recordFights[i].totalKilled++; 
				recordFights[i].gold = recordFights[i].gold + fight.gold;
				dupe = true; 
			}
		}
		if (!dupe) {
			recordFights.push_back(fight);
		}
	}
}

void Sprite::printFightRecord() {
	string margin2 = "        *        ";
	if (recordFights.size() <= 0) {

		cout << "There are no fights recorded... " << endl; 
	}
	else {
		cout << "\n        " << setw(63) << setfill('*') << "" << endl;
		cout << setfill(' ');
		cout << margin2 << setw(20) << "Monster" << setw(15)<< "Total Gold" << setw(10)<<"Killed"<<margin2<<endl;
		cout << margin2 <<setw(20) << "=======" << setw(15)<<"==========" << setw(10)<<"======"<<margin2<< endl;

		for (int i = 0; i < recordFights.size(); i++) {
			//cout << "test" << endl; 
			cout << margin2 << setw(20) << recordFights[i].name << setw(15) << recordFights[i].gold  << setw(10) << recordFights[i].totalKilled << margin2 <<endl; 

		}
		cout << "        " << setw(63) << setfill('*') << "" << endl;
		cout << setfill(' ');
	}
}

vector<Sprite::FightRecord> Sprite::getFightRecords() {

	return recordFights; 

}
string Sprite::getWeaponName() {

	return weaponName;
}
string Sprite::getArmorName() {

	return armorName; 
}