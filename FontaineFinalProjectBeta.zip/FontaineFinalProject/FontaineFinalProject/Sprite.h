#pragma once
#include "stdafx.h"
#include <string>
#include "stdafx.h"
#include <iostream>
#include <vector>


using namespace std; 
class Sprite
{
private:
	string name; 
	int armor; 
	int attack; 
	int weapon; 
	int body; 
	int intelligence; 
	int quickness; 
	int strength; 
	int cash;
	int hitPoints; 
	int toHit;
	int MAXHITPOINTS; 
	string weaponName; 
	string armorName; 

	struct FightRecord {

		string name; 
		int gold; 
		int totalKilled; 

		FightRecord(string n, int g) {
			name = n; 
			gold = g; 
			totalKilled = 1; 

		}
	};

	vector<FightRecord> recordFights; 

public:
	Sprite();
	Sprite(string na, int bd, int intel, int qk, int str); 
	Sprite(string na, int bd, int intel, int qk, int str, int gld, int arm, int weap, int hp);
	~Sprite();
	bool isAlive(); 
	void setName(string n); 
	string getName();
	void setArmor(int a);
	int getArmor();
	void setArmor(int a, string n);
	int getAttack(); 
	void setAttack(); 
	int getWeapon(); 
	void setWeapon(int w);
	void setWeapon(int w, string n);
	int getBody(); 
	void setBody(int b);
	void setQuickness(int q); 
	int getQuickness();
	void setIntelligence(int i); 
	int getIntelligence(); 
	int getCash(); 
	void setCash(int c);
	string toString(); 
	void printSheet(); 
	int getHitPoints(); 
	void setHitPoints(int hp);
	int getToHit(); 
	void setToHit(); 
	int getStrength(); 
	void setStrength(int s); 
	void setMAXHITPOINTS(); 
	int getMAXHITPOINTS(); 
	string hitPointsToString(); 
	string MAXHITPOINTSToString(); 
	int Attack(int targetNo); 
	void ResolveAttack(string attacker, int damage); 
	void saveSprite(); 
	void loadSpriteFromFile(string file); 
	void addFightRecord(Sprite *NPC);
	void printFightRecord(); 
	vector<FightRecord> getFightRecords();
	string getWeaponName(); 
	string getArmorName(); 
	void saveSprite(int pos);
	//*Object copySprite(); 
	
	
};

