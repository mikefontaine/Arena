#include "stdafx.h"
#include "Wolf.h"


Wolf::Wolf()
{
	setName("Wolf");
	setStrength(5);
	setIntelligence(10);
	setQuickness(20);
	setBody(5);
	setWeapon(2);
	setArmor(0);
	setCash(200);
	setMAXHITPOINTS();
	setHitPoints(getMAXHITPOINTS());
	setToHit();
	setAttack();
}


Wolf::~Wolf()
{
}
