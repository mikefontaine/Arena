#pragma once
#include "Monster.h"
class Wolf :
	public Monster
{
public:
	Wolf();
	~Wolf();
};

